import numpy as np
from django.shortcuts import render
import joblib
import os
import pandas as pd

# Load the model and preprocessor
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
model = joblib.load(os.path.join(BASE_DIR, 'predict/model/decision_tree_regressor.pkl'))
preprocessor = joblib.load(os.path.join(BASE_DIR, 'predict/model/preprocessor.pkl'))

def predict_yield(request):
    predicted_yield = None  # Initialize variable for predicted yield

    if request.method == 'POST':
        data = request.POST
        Year = int(data.get('Year'))
        average_rain_fall_mm_per_year = float(data.get('average_rain_fall_mm_per_year'))
        pesticides_tonnes = float(data.get('pesticides_tonnes'))
        avg_temp = float(data.get('avg_temp'))
        Area = data.get('Area')  # Get the selected country from the dropdown
        Item = data.get('Item')

        # Prepare features for prediction
        features = np.array([[Year, average_rain_fall_mm_per_year, pesticides_tonnes, avg_temp, Area, Item]], dtype=object)
        transform_features = preprocessor.transform(features)
        predicted_yield = model.predict(transform_features).reshape(-1, 1)[0][0]

    # Load countries from the dataset and pass them to the template
    dataset = pd.read_csv(os.path.join(BASE_DIR, 'predict/model/yield_df.csv'))
    countries = dataset['Area'].unique().tolist()  # Extract unique countries

    return render(request, 'form.html', {'predicted_yield': predicted_yield, 'countries': countries})
